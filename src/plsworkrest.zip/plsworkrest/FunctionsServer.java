import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class FunctionsServer {
    public static void main(String[] args) {
        try {
            Functions functions = new Functions();
	
	    System.setProperty("java.rmi.server.hostname", "192.168.56.101");
            // Create a registry and bind the remote object's stub in the registry
            //LocateRegistry.createRegistry(1099); // Default RMI registry port
            Naming.rebind("FunctionsServer", functions);

            System.out.println("Server ready");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
